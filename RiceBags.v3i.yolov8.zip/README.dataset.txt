# RiceBags > 2023-10-26 11:15pm
https://universe.roboflow.com/dr-naman-goyal/ricebags

Provided by a Roboflow user
License: CC BY 4.0

